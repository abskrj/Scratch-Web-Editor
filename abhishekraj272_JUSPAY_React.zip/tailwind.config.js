module.exports = {
  darkMode: "class",
  purge: ["./src/**/*.js"],
  variants: {},
  plugins: [],
};
